﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KelseyAbreuWebsite.Classes
{
    [Serializable]
    public class Player
    {
        public string Name { set; get; }
        public int TotalGames { set; get; }
        public int TotalWins { set; get; }
    }
}