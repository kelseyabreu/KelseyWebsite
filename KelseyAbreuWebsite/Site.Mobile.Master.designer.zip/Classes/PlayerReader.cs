﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace KelseyAbreuWebsite.Classes
{
    public static class PlayerFileHandler
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="PageName">pagename string to appropriately find file</param>
        /// <returns></returns>
        public static List<Player> GetPlayers(string PageName)
        {
            List<Player> lpPlayers = new List<Player>();
            try {
                using (Stream stream = File.Open(System.Web.HttpContext.Current.Server.MapPath("~/GameRecords/" + PageName + "_PlayerScores.serial"), FileMode.Open))
                {
                    var binaryFormatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                    lpPlayers = (List<Player>)binaryFormatter.Deserialize(stream);
                }
            }catch(FileNotFoundException)
            {

            }

            return lpPlayers;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="PageName">pagename string to appropriately name file</param>
        /// <param name="Players">List of Players to save</param>
        public static int WritePlayers(string PageName,List<Player> Players)
        {
            int iSuccess = 0;
            try
            {
                using (Stream stream = File.Open(System.Web.HttpContext.Current.Server.MapPath("~/GameRecords/"+PageName + "_PlayerScores.serial"), FileMode.Create))
                {
                    var binaryFormatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                    binaryFormatter.Serialize(stream, Players);
                }
            }
            catch (Exception)
            {
                iSuccess = 1;
            }

            return iSuccess;
        }
    }
}